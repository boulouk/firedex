
import os
import signal
import subprocess

from mininet_topology import MininetTopology
from mininet.net import Mininet
from mininet.node import RemoteController

class MininetNetwork:

    def __init__(self, bandwidth, latency, error_rate):
        self.__switch = "s1"
        self.__dummy_switch = "s254"
        self.__switch_protocols = "OpenFlow13"

        self.__bandwidth = bandwidth
        self.__latency = latency
        self.__error_rate = error_rate

        self.__hosts = []

        self.__network = Mininet()
        self.__processes = []

    def add_host(self, name, mac, ip):
        self.__hosts.append( { "name": name, "mac": mac, "ip": ip } )

    def host_by_name(self, name):
        for host in self.__network.hosts:
            if host.name == name:
                return host
        return None

    def start(self):
        topology = MininetTopology()

        topology.addSwitch(
            name = self.__switch,
            protocols = self.__switch_protocols,
        )

        topology.addSwitch(
            name = self.__dummy_switch,
            protocols = self.__switch_protocols,
        )

        topology.addLink(
            node1 = self.__switch,
            node2 = self.__dummy_switch
        )

        for host in self.__hosts:
            topology.addHost(
                name = host["name"],
                mac = host["mac"],
                ip = host["ip"]
            )

            if host["name"] == "broker":
                topology.addLink(
                    node1 = host["name"],
                    node2 = self.__dummy_switch
                )
            else:
                topology.addLink(
                    node1 = host["name"],
                    node2 = self.__switch
                )

        self.__network = Mininet(
            topo = topology,
            controller = RemoteController,
            waitConnected = True
        )

        self.__network.addNAT().configDefault()

        self.__network.start()

    def priority_queues(self, number_priorities):
        bandwidth = self.__bandwidth * 8

        command = "sudo ovs-vsctl"
        command += " -- set port %s-eth%s qos=@newqos -- " % (self.__dummy_switch, str(1))
        command += "--id=@newqos create qos type=linux-htb other-config:max-rate=%s " % str(bandwidth)
        command += "queues="
        for priority in range(number_priorities):
            queue_name = str(priority)
            queue_identifier = "@%sq" % queue_name
            command += "%s=%s," % (queue_name, queue_identifier)
        command = command[:-1]
        command += " -- "
        for priority in range(number_priorities):
            queue_name = str(priority)
            queue_identifier = "@%sq" % queue_name
            command += "--id=%s create queue other-config:priority=%s -- " % (queue_identifier, queue_name)

        process = subprocess.Popen(
            command,
            shell = True,
            stdin = open(os.devnull),
            stdout = open(os.devnull),
            stderr = open(os.devnull)
        )

        process.wait()

    def topology_discovery(self):
        self.__network.pingAll()

    def execute(self, name, command):
        host = self.host_by_name(name)
        process = host.popen(command, shell = False)
        self.__processes.append(process)

    def stop(self):
        for process in self.__processes:
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except Exception:
                pass

        self.__processes = []
        self.__network.stop()


