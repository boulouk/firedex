
from mininet.topo import Topo

class MininetTopology(Topo):

    def __init__(self):
        Topo.__init__(self)
