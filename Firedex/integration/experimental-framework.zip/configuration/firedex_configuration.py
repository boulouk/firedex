
import json
from scenario.firedex_scenario import *

class FiredexConfiguration:

    def __init__(self):
        self.__experiment_duration = EXPERIMENT_DURATION

        self.__network_flows = NETWORK_FLOWS
        self.__priorities = PRIORITIES

    def experiment_duration(self):
        return self.__experiment_duration

    def network_flows(self):
        return self.__network_flows

    def priorities(self):
        return self.__priorities

    def json(self):
        object = {
            "experiment_duration": self.experiment_duration(),

            "network_flows": self.network_flows(),
            "priorities": self.priorities()
        }

        result = json.dumps(object, indent = 4, sort_keys = False)
        return result