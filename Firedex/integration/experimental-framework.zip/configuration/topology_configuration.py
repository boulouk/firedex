
import json
from scenario.topology_scenario import *

class TopologyConfiguration:

    def __init__(self):
        self.__broker = BROKER
        self.__publishers = PUBLISHERS
        self.__subscribers = SUBSCRIBERS

    def broker(self):
        return self.__broker

    def subscribers(self):
        return self.__subscribers

    def publishers(self):
        return self.__publishers

    def json(self):
        object = {
            "broker": self.broker(),
            "publishers": self.publishers(),
            "subscribers": self.subscribers()
        }

        result = json.dumps(object, indent = 4, sort_keys = False)
        return result
