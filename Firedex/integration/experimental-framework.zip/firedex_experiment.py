
import os
import requests
import time

from topology.mininet_network import MininetNetwork

from configuration.firedex_configuration import *
from configuration.network_configuration import *
from configuration.topology_configuration import *

FIREDEX_MIDDLEWARE_IP = "127.0.0.1"
FIREDEX_MIDDLEWARE_PORT = 8888
FIREDEX_BASE_API = "http://127.0.0.1:8888/api/firedex"

class Configuration:

    def __init__(self):
        self.network_configuration = None
        self.topology_configuration = None
        self.firedex_configuration = None

configuration = Configuration()

def network_scenario():
    configuration.network_configuration = NetworkConfiguration()
    print("Network configuration: ")
    print(configuration.network_configuration.json())
    print("")

def topology_scenario():
    configuration.topology_configuration = TopologyConfiguration()
    print("Topology configuration: ")
    print(configuration.topology_configuration.json())
    print("")

def firedex_scenario():
    configuration.firedex_configuration = FiredexConfiguration()
    print("Firedex configuration: ")
    print(configuration.firedex_configuration.json())
    print("")

def push_network_configuration():
    print("Pushing network configuration...")

    url = FIREDEX_BASE_API + "/push-network-configuration/"
    body = configuration.network_configuration.json()

    response = requests.post(
        url = url,
        json = body
    )

    content = response.json()

    print("Network configuration pushed.")
    print("")

def push_topology_configuration():
    print("Pushing topology configuration...")

    url = FIREDEX_BASE_API + "/push-topology-configuration/"
    body = configuration.topology_configuration.json()

    response = requests.post(
        url = url,
        json = body
    )

    content = response.json()

    print("Topology configuration pushed.")
    print("")

def push_firedex_configuration():
    print("Pushing Firedex configuration...")

    url = FIREDEX_BASE_API + "/push-firedex-configuration/"
    body = configuration.firedex_configuration.json()

    response = requests.post(
        url = url,
        json = body
    )

    content = response.json()

    print("Firedex configuration pushed.")
    print("")

def system_configuration():
    print("Getting system configuration...")

    url = FIREDEX_BASE_API + "/system-configuration/"
    body = configuration.firedex_configuration.json()

    response = requests.post(
        url = url,
        json = body
    )

    content = response.json()
    system_configuration_file = open("./output/system_configuration.json", "w+")
    system_configuration_file.write( json.dumps(content, indent = 4, sort_keys = False) )
    system_configuration_file.close()

    print("System configuration obtained.")
    print("")

def start_network():
    print("Starting network...")

    broker = configuration.topology_configuration.broker()
    publishers = configuration.topology_configuration.publishers()
    subscribers = configuration.topology_configuration.subscribers()

    bandwidth = configuration.network_configuration.bandwidth()
    latency = configuration.network_configuration.latency()
    error_rate = configuration.network_configuration.error_rate()

    mininet_network = MininetNetwork(
        bandwidth = bandwidth,
        latency = latency,
        error_rate = error_rate
    )

    identifier = broker["identifier"]
    mac = broker["mac"]
    ip = broker["ip"]

    mininet_network.add_host(identifier, mac, ip)

    for subscriber in subscribers:
        identifier = subscriber["identifier"]
        mac = subscriber["mac"]
        ip = subscriber["ip"]

        mininet_network.add_host(identifier, mac, ip)

    for publisher in publishers:
        identifier = publisher["identifier"]
        mac = publisher["mac"]
        ip = publisher["ip"]

        mininet_network.add_host(identifier, mac, ip)

    mininet_network.start()

    print("Network started.")
    print("")

    time.sleep(1)

    print("Priority queues.")
    priorities = configuration.firedex_configuration.priorities()
    mininet_network.priority_queues(priorities)

    time.sleep(1)
    print("")

    return mininet_network

def topology_discovery(mininet_network):
    print("Topology discovery...")

    time.sleep(1)

    mininet_network.topology_discovery()

    time.sleep(1)

    print("Topology discovery completed.")
    print("")

def start_brokers(mininet_network):
    print("Starting broker...")

    broker = configuration.topology_configuration.broker()
    identifier = broker["identifier"]
    command = "java -jar ./application/broker/Broker.jar ./application/broker/broker.configuration"
    mininet_network.execute(identifier, command)

    print("Broker started.")
    print("")

    time.sleep(1)

    print("Starting gateway...")

    command = "java -jar ./application/gateway/Gateway.jar ./application/gateway/gateway.properties"
    mininet_network.execute(identifier, command)

    print("Gateway started.")
    print("")

def start_subscribers(mininet_network):
    print("Starting subscribers...")

    experiment_duration = configuration.firedex_configuration.experiment_duration()

    broker = configuration.topology_configuration.broker()
    subscribers = configuration.topology_configuration.subscribers()

    for subscriber in subscribers:
        identifier = subscriber["identifier"]
        subscriber_configuration_file = "./application/subscriber/%s.json" % identifier
        subscriber_output_file = "./application/subscriber/output_%s.json" % identifier

        subscriber_configuration = {
            "middleware": {
                "host": "10.0.2.15",
                "port": "8888"
            },
            "broker": {
                "host": broker["ip"],
                "port": "1883"
            },
            "brokerGateway": {
                "host": broker["ip"],
                "port": "20000"
            },
            "subscriber": {
                "identifier": identifier,
                "runningTime": experiment_duration,
                "type": "UDP",
                "subscriptions": []
            }
        }

        for subscription in subscriber["subscriptions"]:
            subscriber_configuration["subscriber"]["subscriptions"].append(
                {
                    "topic": subscription["topic"],
                    "utilityFunction": subscription["utility_function"]
                }
            )

        configuration_file = open(subscriber_configuration_file, "w+")
        configuration_file.write(json.dumps(subscriber_configuration, indent = 4))
        configuration_file.close()

        command = "java -jar ./application/subscriber/Subscriber.jar %s %s" % (subscriber_configuration_file, subscriber_output_file)
        mininet_network.execute(identifier, command)

        print("Subscriber started (%s)." % identifier)

    print("")

def start_publishers(mininet_network):
    print("Starting publishers...")

    experiment_duration = configuration.firedex_configuration.experiment_duration()

    broker = configuration.topology_configuration.broker()
    publishers = configuration.topology_configuration.publishers()

    for publisher in publishers:
        identifier = publisher["identifier"]
        publisher_configuration_file = "./application/publisher/%s.json" % identifier
        publisher_output_file = "./application/publisher/output_%s.json" % identifier

        publisher_configuration = {
            "broker": {
                "host": broker["ip"],
                "port": "1883"
            },
            "publisher": {
                "identifier": identifier,
                "runningTime": experiment_duration,
                "publishings": []
            }
        }

        for publishing in publisher["publishings"]:
            publisher_configuration["publisher"]["publishings"].append(
                {
                    "topic": publishing["topic"],
                    "qualityOfService": "0",
                    "retained": "false",
                    "parameter": publishing["rate"]
                }
            )

        configuration_file = open(publisher_configuration_file, "w+")
        configuration_file.write( json.dumps(publisher_configuration, indent = 4) )
        configuration_file.close()

        command = "java -jar ./application/publisher/Publisher.jar %s %s" % (publisher_configuration_file, publisher_output_file)
        mininet_network.execute(identifier, command)

        print("Publisher started (%s)." % identifier)

    print("")

def wait():
    experiment_duration = configuration.firedex_configuration.experiment_duration()
    print("Waiting...")

    time.sleep(experiment_duration + 30)

    print("Experiment completed.")
    print("")

def stop_network(mininet_network):
    print("Stopping network...")

    time.sleep(1)

    mininet_network.stop()

    print("Network stopped.")
    print("")

    time.sleep(1)

def analyize():
    print("--- Analysis ---")

    publishers = configuration.topology_configuration.publishers()

    total_publishings = { }

    for publisher in publishers:
        identifier = publisher["identifier"]
        publisher_configuration_file = "./application/publisher/%s.json" % identifier
        publisher_output_file = "./application/publisher/output_%s.json" % identifier

        result = open(publisher_output_file, 'r').read()
        publishings = json.loads(result)
        for publishing in publishings:
            topic = publishing["topic"]
            messages = int( publishing["messages"] )
            if topic not in total_publishings.keys():
                total_publishings[topic] = 0

            current_messages = total_publishings[topic]
            del total_publishings[topic]
            total_publishings[topic] = current_messages + messages

        os.remove(publisher_configuration_file)
        os.remove(publisher_output_file)

    output_file = open("./output/output.json", "w+")
    output_file.write( json.dumps(total_publishings, indent = 4, sort_keys = False) )
    for publishing, messages in total_publishings.items():
        print( "topic: %s, messages: %d" % (publishing, messages) )

def experiment():
    network_scenario()
    topology_scenario()
    firedex_scenario()

    push_network_configuration()
    push_topology_configuration()
    push_firedex_configuration()
    system_configuration()

    mininet_network = start_network()
    topology_discovery(mininet_network)

    start_brokers(mininet_network)
    time.sleep(3)
    start_subscribers(mininet_network)
    time.sleep(3)
    start_publishers(mininet_network)

    wait()

    stop_network(mininet_network)

    analyize()


if __name__ == "__main__":
    experiment()
