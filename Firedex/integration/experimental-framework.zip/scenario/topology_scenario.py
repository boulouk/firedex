
BROKER = {
    "identifier": "broker",
    "mac": "00:00:00:00:00:01",
    "ip": "10.0.0.1"
}

SUBSCRIBERS = [
    {
        "identifier": "sub1",
        "mac": "00:00:00:00:00:02",
        "ip": "10.0.0.2",
        "subscriptions": [
            { "topic": "smoke", "utility_function": 2 },
            { "topic": "fire", "utility_function": 10 }
        ]
    },
    {
        "identifier": "sub2",
        "mac": "00:00:00:00:00:05",
        "ip": "10.0.0.5",
        "subscriptions": [
            { "topic": "smoke", "utility_function": 10 },
            { "topic": "fire", "utility_function": 2 }
        ]
    }
]

PUBLISHERS = [
    {
        "identifier": "pub3",
        "mac": "00:00:00:00:00:08",
        "ip": "10.0.0.8",
        "publishings": [ { "topic": "smoke", "rate": 5 }, { "topic": "fire", "rate": 5 } ]
    }
]
