
def from_datapath_identifier_to_switch_identifier(identifier):
    switch_identifier = "S" + str(identifier)
    return switch_identifier
