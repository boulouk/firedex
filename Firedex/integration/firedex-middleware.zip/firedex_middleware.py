
import json
import requests

from algorithms.priorities.priority_greedy_local import PriorityGreedyLocal
from algorithms.priorities.priority_greedy_global import PriorityGreedyGlobal
from algorithms.drop_rates.drop_rate_flat import DropRateFlat
from algorithms.drop_rates.drop_rate_linear import DropRateLinear
from algorithms.drop_rates.drop_rate_exponential import DropRateExponential
from configuration.algorithm_configuration import AlgorithmConfiguration

from flask import Flask, request, jsonify


application = Flask("firedex-middleware")

class Configuration:

    def __init__(self):
        self.algorithm_configuration = AlgorithmConfiguration()

        self.network_configuration = None
        self.topology_configuration = None
        self.firedex_configuration = None

        self.system_configuration = None

configuration = Configuration()

priority_algorithm = None
if configuration.algorithm_configuration.priority_algorithm() == "greedy_local":
    priority_algorithm = PriorityGreedyLocal()
if configuration.algorithm_configuration.priority_algorithm() == "greedy_global":
    priority_algorithm = PriorityGreedyGlobal()

drop_rate_algorithm = None
if configuration.algorithm_configuration.drop_rate_algorithm() == "flat":
    drop_rate_algorithm = DropRateFlat()
if configuration.algorithm_configuration.drop_rate_algorithm() == "linear":
    drop_rate_algorithm = DropRateLinear()
if configuration.algorithm_configuration.drop_rate_algorithm() == "exponential":
    drop_rate_algorithm = DropRateExponential()

@application.route("/api/firedex/push-network-configuration/", methods = ["POST"])
def push_network_configuration():
    json_request = request.json
    network_configuration = json.loads(json_request)
    configuration.network_configuration = network_configuration

    return jsonify( {"result": "successful"} )

@application.route("/api/firedex/push-topology-configuration/", methods = ["POST"])
def push_topology_configuration():
    json_request = request.json
    topology_configuration = json.loads(json_request)
    configuration.topology_configuration = topology_configuration

    return jsonify( {"result": "successful"} )

@application.route("/api/firedex/push-firedex-configuration/", methods = ["POST"])
def push_firedex_configuration():
    json_request = request.json
    firedex_configuration = json.loads(json_request)
    configuration.firedex_configuration = firedex_configuration

    return jsonify( {"result": "successful"} )

@application.route("/api/firedex/system-configuration/", methods = ["POST"])
def system_configuration():
    subscriptions = []
    for subscriber in configuration.topology_configuration["subscribers"]:
        identifier = subscriber["identifier"]
        mac = subscriber["mac"]
        ip = subscriber["ip"]

        subscriber_subscriptions = subscriber["subscriptions"]
        for subscription in subscriber_subscriptions:
            subscription["identifier"] = identifier
            subscription["mac"] = mac
            subscription["ip"] = ip

            subscriptions.append(subscription)

    subscriptions = priority_algorithm.apply(configuration, subscriptions)
    subscriptions = drop_rate_algorithm.apply(configuration, subscriptions)

    configuration.system_configuration = subscriptions

    url = "http://127.0.0.1:8080/api/flow/push-configuration/"
    data = json.dumps(subscriptions)
    response = requests.post(url, data=data)
    content = response.json()
    print(content)

    return jsonify(subscriptions)

@application.route("/api/firedex/subscriptions/", methods = ["POST"])
def subscriptions():
    json_request = request.json
    identifier = json_request["identifier"]
    subscriptions = json_request["subscriptions"]

    subscriber_configuration = []
    for subscription in subscriptions:
        topic = subscription["topic"]
        utility_function = subscription["utilityFunction"]
        subscriber_configuration.append( __subscription_by_subscriber(identifier, topic, utility_function) )

    return jsonify(subscriber_configuration)

def __subscription_by_subscriber(identifier, topic, utility_function):
    for subscription in configuration.system_configuration:
        if subscription["identifier"] == identifier and subscription["topic"] == topic and subscription["utility_function"] == utility_function:
            return subscription
    return None

if __name__ == "__main__":
    application.run(host = "0.0.0.0", port = 8888, debug = True)
