
import json
from scenario.algorithm_scenario import *

class AlgorithmConfiguration:

    def __init__(self):
        self.__priority_algorithm = PRIORITY_ALGORITHM
        self.__drop_rate_algorithm = DROP_RATE_ALGORITHM

        self.__tolerance = TOLERANCE

        self.__topic_information = TOPIC_INFORMATION

    def priority_algorithm(self):
        return self.__priority_algorithm

    def drop_rate_algorithm(self):
        return self.__drop_rate_algorithm

    def tolerance(self):
        return self.__tolerance

    def topic_information(self):
        return self.__topic_information

    def json(self):
        object = {
            "priority_algorithm": self.priority_algorithm(),
            "drop_rate_algorithm": self.drop_rate_algorithm(),

            "tolerance": self.tolerance(),

            "topic_information": self.topic_information()
        }
        result = json.dumps(object, indent = 4, sort_keys = False)
        return result
