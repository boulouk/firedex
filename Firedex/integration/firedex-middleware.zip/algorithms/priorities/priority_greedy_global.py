
from operator import itemgetter
from algorithms.priorities.priority_algorithm import PriorityAlgorithm

class PriorityGreedyGlobal(PriorityAlgorithm):

    def __init__(self):
        super(PriorityGreedyGlobal).__init__()

    def apply(self, configuration, all_subscriptions):
        network_flows = configuration.firedex_configuration["network_flows"]
        priorities = configuration.firedex_configuration["priorities"]

        sorted_subscriptions = sorted(all_subscriptions, key = itemgetter("utility_function"), reverse = True)
        grouped_subscriptions = self.__even_group_split(sorted_subscriptions, network_flows)

        prioritized_subscriptions = []
        for priority, subscriptions in zip( range(priorities), grouped_subscriptions ):
            for subscription in subscriptions:
                subscription["port"] = 10000 + priority
                subscription["priority"] = priority

                prioritized_subscriptions.append(subscription)

        return prioritized_subscriptions

    def __even_group_split(self, subscriptions, groups):
        groups_size = []
        base_size = subscriptions.__len__() // groups
        surplus = subscriptions.__len__() % groups

        for i in range(groups):
            group_size = base_size
            if i < surplus:
                group_size = group_size + 1
            groups_size.append(group_size)

        grouped_subscriptions = []

        index = 0
        for i in range(groups):
            group_size = groups_size[i]
            grouped_subscriptions.append( subscriptions[index:index + group_size] )
            index = index + group_size

        return grouped_subscriptions
