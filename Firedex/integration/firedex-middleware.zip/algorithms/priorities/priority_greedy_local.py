
from operator import itemgetter
from algorithms.priorities.priority_algorithm import PriorityAlgorithm

class PriorityGreedyLocal(PriorityAlgorithm):

    def __init__(self):
        super(PriorityGreedyLocal).__init__()

    def apply(self, configuration, all_subscriptions):
        network_flows = configuration.firedex_configuration["network_flows"]
        priorities = configuration.firedex_configuration["priorities"]

        prioritized_subscriptions = []

        for subscriber in configuration.topology_configuration["subscribers"]:
            identifier = subscriber["identifier"]
            subscriptions = self.__by_subscriber(identifier, all_subscriptions)

            sorted_subscriptions = sorted(subscriptions, key = itemgetter("utility_function"), reverse = True)
            grouped_subscriptions = self.__even_group_split(sorted_subscriptions, network_flows)

            prioritized_subscriptions_for_subscriber = []
            for priority, subscriptions in zip( range(priorities), grouped_subscriptions ):
                for subscription in subscriptions:
                    subscription["port"] = 10000 + priority
                    subscription["priority"] = priority

                    prioritized_subscriptions_for_subscriber.append(subscription)

            for prioritized_subscription_for_subscriber in prioritized_subscriptions_for_subscriber:
                prioritized_subscriptions.append(prioritized_subscription_for_subscriber)

        return prioritized_subscriptions

    def __by_subscriber(self, identifier, subscriptions):
        by_subscriber = []

        for subscription in subscriptions:
            if subscription["identifier"] == identifier:
                by_subscriber.append(subscription)

        return by_subscriber

    def __even_group_split(self, subscriptions, groups):
        groups_size = []
        base_size = subscriptions.__len__() // groups
        surplus = subscriptions.__len__() % groups

        for i in range(groups):
            group_size = base_size
            if i < surplus:
                group_size = group_size + 1
            groups_size.append(group_size)

        grouped_subscriptions = []

        index = 0
        for i in range(groups):
            group_size = groups_size[i]
            grouped_subscriptions.append( subscriptions[index:index + group_size] )
            index = index + group_size

        return grouped_subscriptions
