
import numpy
from algorithms.drop_rates.drop_rate_algorithm import DropRateAlgorithm

class DropRateExponential(DropRateAlgorithm):

    def __init__(self):
        super(DropRateExponential).__init__()

    def apply(self, configuration, subscriptions):
        beta = self.__beta(configuration, subscriptions)

        for subscription in subscriptions:
            drop_rate = 1 - ( beta ** (-subscription["priority"]) )
            subscription["drop_rate"] = drop_rate

        return subscriptions

    def __beta(self, configuration, subscriptions):
        bandwidth = configuration.network_configuration["bandwidth"]
        tolerance = configuration.algorithm_configuration.tolerance()

        topic_to_rate = {}
        for publisher in configuration.topology_configuration["publishers"]:
            for publishing in publisher["publishings"]:
                topic = publishing["topic"]
                rate = publishing["rate"]
                if topic not in topic_to_rate.keys():
                    topic_to_rate[topic] = 0

                topic_to_rate[topic] = topic_to_rate[topic] + rate

        topic_to_size = {}
        for topic_information in configuration.algorithm_configuration.topic_information():
            topic_to_size[ topic_information["topic"] ] = topic_information["size"]

        subscriptions_load_by_priority = {}

        for subscription in subscriptions:
            topic = subscription["topic"]
            priority = subscription["priority"]

            if topic not in topic_to_rate: # no publisher for that topic
                rate = 0
            else:
                rate = topic_to_rate[topic]
            size = topic_to_size[topic]

            if priority not in subscriptions_load_by_priority:
                subscriptions_load_by_priority[priority] = 0

            subscriptions_load_by_priority[priority] = subscriptions_load_by_priority[priority] + (rate * size)

        coefficients = []
        for priority in sorted( subscriptions_load_by_priority.keys(), reverse = True ):
            coefficients.append( subscriptions_load_by_priority[priority] )

        coefficients[-1] = coefficients[-1] - (bandwidth * (1 - tolerance))

        roots = numpy.roots(coefficients)

        true_roots = []
        for root in roots:
            if numpy.isreal(root) and 0 < root <= 1:
                true_roots.append(root)

        if true_roots.__len__() == 0:
            true_roots.append(1)

        alpha = numpy.amax(true_roots)
        beta = 1 / alpha

        return beta
