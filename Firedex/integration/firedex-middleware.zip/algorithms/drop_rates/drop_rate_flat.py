
from algorithms.drop_rates.drop_rate_algorithm import DropRateAlgorithm

class DropRateFlat(DropRateAlgorithm):

    def __init__(self):
        super(DropRateFlat).__init__()

    def apply(self, configuration, subscriptions):
        beta = self.__beta(configuration, subscriptions)

        for subscription in subscriptions:
            subscription["drop_rate"] = beta

        return subscriptions

    def __beta(self, configuration, subscriptions):
        bandwidth = configuration.network_configuration["bandwidth"]
        tolerance = configuration.algorithm_configuration.tolerance()

        topic_to_rate = {}
        for publisher in configuration.topology_configuration["publishers"]:
            for publishing in publisher["publishings"]:
                topic = publishing["topic"]
                rate = publishing["rate"]
                if topic not in topic_to_rate.keys():
                    topic_to_rate[topic] = 0

                topic_to_rate[topic] = topic_to_rate[topic] + rate

        topic_to_size = {}
        for topic_information in configuration.algorithm_configuration.topic_information():
            topic_to_size[ topic_information["topic"] ] = topic_information["size"]

        subscriptions_load = 0
        for subscription in subscriptions:
            topic = subscription["topic"]

            if topic not in topic_to_rate: # no publisher for that topic
                rate = 0
            else:
                rate = topic_to_rate[topic]
            size = topic_to_size[topic]

            subscriptions_load = subscriptions_load + (rate * size)

        if subscriptions_load < (bandwidth * (1 - tolerance)):
            return 0

        beta = - ( bandwidth * (1 - tolerance) ) / subscriptions_load + 1
        return beta
