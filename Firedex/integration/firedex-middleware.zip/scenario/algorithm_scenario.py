
PRIORITY_ALGORITHM = "greedy_local"
DROP_RATE_ALGORITHM = "exponential"

TOLERANCE = 0.3

TOPIC_INFORMATION = [
    {
        "topic": "smoke",
        "size": 100
    },
    {
        "topic": "fire",
        "size": 100
    },
    {
        "topic": "temperature",
        "size": 100
    },
    {
        "topic": "hydro",
        "size": 100
    }
]
